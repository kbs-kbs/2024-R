mydata <- c(60, 62, 64, 65, 68, 69, 120)
var(mydata)           # 분산, 평균에서 떨어진 정도
sd(mydata)            # 표준편차
range(mydata)         # 값의 범위

diff(range(mydata))   # 최댓값, 최솟값의 차이??
diff(c(150, 22))
diff(c(10, 100))
