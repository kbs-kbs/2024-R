sample(1:20, size=5)
sample(1:20, size=5)
sample(1:20, size=5)

set.seed(100)
sample(1:20, size=5)
set.seed(100)
sample(1:20, size=5)
set.seed(100)
sample(1:20, size=5)

set.seed(100)
sample(1:4, size=5) # 오류
sample(1:4, size=5, replace=T)
