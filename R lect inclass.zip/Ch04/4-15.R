apply(iris[,1:4], 1, mean)  # row 방향으로 함수 적용
apply(iris[,1:4], 2, mean)  # col 방향으로 함수 적용

