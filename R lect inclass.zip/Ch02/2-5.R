a <- 125 
a          
print(a)
