x <- c(1,2,3)                   # 숫자형 벡터
y <- c("a","b","c")             # 문자형 벡터
z <- c(TRUE,TRUE, FALSE, TRUE)  # 논리형 벡터
x                               # x에 저장된 값을 출력
y
z
