z <- merge(x,y, by=c("name"))
z

z <- merge(x,y)
z
