# 1~4열의 값 중 5보다 큰 값의 행과 열의 위치
idx <- which(iris[,1:4]>5.0, arr.ind =TRUE)
idx

iris[,1:4][idx[1, 1], idx[1, 2]]
