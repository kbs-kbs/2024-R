merge(x,y, all.x=T)   # 첫 번째 데이터셋의 행들은 모두 표시되도록
merge(x,y, all.y=T)   # 두 번째 데이터셋의 행들은 모두 표시되도록
merge(x,y, all=T)     # 두 데이터셋의 모든 행들이 표시되도록
merge(x,y, all=T, by=c("name"))     # 두 데이터셋의 모든 행들이 표시되도록
