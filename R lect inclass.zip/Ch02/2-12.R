score <- c(90,85,70)                    # 성적
score
names(score)                            # score에 저장된 값들의 이름을 보이시오
names(score) <- c("John","Tom","Jane")  # 값들에 이름을 부여
names(score)                            # score에 저장된 값들의 이름을 보이시오
score                                   # 이름과 함께 값이 출력   
