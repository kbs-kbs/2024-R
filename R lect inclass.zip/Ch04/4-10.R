sum <- 0
for (i in 1:100) {
  sum <- sum + i    # sum에 i 값을 누적
}
print(sum)
