favorite <- c('WINTER', 'SUMMER', 'SPRING', 'SUMMER', 'SUMMER',
              'FALL', 'FALL', 'SUMMER', 'SPRING', 'SPRING')

favorite                          # favorite의 내용 출력
table(favorite)                   # 도수분포표 계산
table(favorite)/length(favorite)  # 비율 출력

print(favorite)                          # favorite의 내용 출력
print(table(favorite))                   # 도수분포표 계산
print(table(favorite)/length(favorite))  # 비율 출력
