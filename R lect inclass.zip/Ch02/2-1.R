2+3
(3+6)*8
2^3         # 2의 세제곱
  
print(10 %% 3)

NULL
NA
NaN
Inf
-Inf

na
