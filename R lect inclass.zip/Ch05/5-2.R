ds <- table(favorite)
ds                
barplot(ds, main='favorite season')
