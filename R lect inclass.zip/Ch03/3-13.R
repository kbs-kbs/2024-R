z <- matrix(1:20, nrow=4, ncol=5)
z
t(z)   # 행과 열 방향 전환
