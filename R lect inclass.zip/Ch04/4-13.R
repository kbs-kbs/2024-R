sum <- 0
for(i in 1:10) {
  sum <- sum + i
  if (i>=5) break
}
sum
