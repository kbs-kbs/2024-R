print(3 + 4)
print(3 * 4)
