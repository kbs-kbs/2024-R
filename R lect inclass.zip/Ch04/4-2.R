job.type <- 'A'
bonus <- 100

if(job.type == 'A') {
  bonus <- 200            # 직무 유형이 A일 때 실행
}
print(bonus)


if (job.type == 'A') 
  bonus <- 300            # 직무 유형이 A일 때 실행

print(bonus)
