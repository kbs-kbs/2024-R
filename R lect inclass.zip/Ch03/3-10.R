dim(iris)       # 행과 열의 개수 출력
nrow(iris)      # 행의 개수 출력
ncol(iris)      # 열의 개수 출력
colnames(iris)  # 열 이름 출력, names()와 결과 동일
head(iris)      # 데이터셋의 앞부분 일부 출력
tail(iris)      # 데이터셋의 뒷부분 일부 출력
