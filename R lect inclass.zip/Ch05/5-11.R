boxplot(Petal.Length~Species, data=iris, main="품종별 꽃잎의 길이")

boxplot(Petal.Width~Species, data=iris, main="품종별 꽃잎의 너비")
