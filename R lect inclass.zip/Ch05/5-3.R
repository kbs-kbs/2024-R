ds <- table(favorite)
ds                
pie(ds, main='favorite season')
