a <- 10
b <- 20
if (a>5 & b>5) {         # and 사용
  print (a+b)
}
if (a>5 | b>30) {        # or 사용
  print (a*b)
}
