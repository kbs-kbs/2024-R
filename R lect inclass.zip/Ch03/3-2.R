z2 <- matrix(1:20, nrow=4, ncol=5, byrow=T)
z2                                # 매트릭스 z2의 내용을 출력
