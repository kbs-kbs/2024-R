a <- matrix(1:20,4,5)
b <- matrix(21:40,4,5)
a
b

2*a                 # 매트릭스 a에 저장된 값들에 2를 곱하기
b-5
2*a + 3*b

a+b
b-a
b/a
a*b

a <- a*3
b <- b-5

