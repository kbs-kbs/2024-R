mymax(10,15)
a <- mymax(20,15)
b <- mymax(31,45)
print(a+b)
