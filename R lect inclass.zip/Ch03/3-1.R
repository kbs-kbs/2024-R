z <- matrix(1:20, nrow=4, ncol=5)
z                         # 매트릭스 z의 내용을 출력
